# -*- coding: utf-8 -*-
"""Honeycomb HP OfficeJet Service."""
from __future__ import unicode_literals
