# Mirai Telnet Honeypot

Cymmetria Research, 2018.

https://www.cymmetria.com/

Contact: research@cymmetria.com

This honeypot is meant to detect the Mirai worm.
It contains 3 alert types: One for telnet login/logout, one for attempts to interact with the shell, and the third one is a positive ID on Mirai.

It is released under the MIT license for the use of the community.

# See also

Mirai behavior overview: https://isc.sans.edu/diary/21543
