# -*- coding: utf-8 -*-
"""Honeycomb Mirai Worm Monitor Service."""
from __future__ import unicode_literals
