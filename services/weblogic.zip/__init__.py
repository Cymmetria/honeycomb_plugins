# -*- coding: utf-8 -*-
"""Honeycomb Oracle WebLogic Service."""
from __future__ import unicode_literals
