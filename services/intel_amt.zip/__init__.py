# -*- coding: utf-8 -*-
"""Honeycomb Intel AMT Service."""
from __future__ import unicode_literals
