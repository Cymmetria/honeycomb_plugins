# Intel AMT Honeypot

Cymmetria Research, 2018.

https://www.cymmetria.com/

Contact: research@cymmetria.com

The AMT honeypot is designed to catch CVE-2017-5689, the Digest Authentication Bypass.

It is released under the MIT license for the use of the community.

# See also

Exploit source code: https://github.com/rapid7/metasploit-framework/blob/master/modules/auxiliary/scanner/http/intel_amt_digest_bypass.rb