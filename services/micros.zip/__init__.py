# -*- coding: utf-8 -*-
"""Honeycomb Oracle Micros Service."""
from __future__ import unicode_literals
