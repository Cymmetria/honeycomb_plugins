# Xerox 6605dn Honeypot

Cymmetria Research, 2018.

https://www.cymmetria.com/

Contact: research@cymmetria.com

Xerox 6605dn is a low interaction honeypot meant to detect interaction with the printer on the PJL and HTTP ports.

It is released under the MIT license for the use of the community.
