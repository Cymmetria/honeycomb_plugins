# -*- coding: utf-8 -*-
"""Honeycomb Xerox service."""
from __future__ import unicode_literals
