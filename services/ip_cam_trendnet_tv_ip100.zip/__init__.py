# -*- coding: utf-8 -*-
"""Honeycomb IP Cam TRENDnet TV-IP100 Service."""
from __future__ import unicode_literals
