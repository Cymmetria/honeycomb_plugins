"""Honeycomb banner integration."""
