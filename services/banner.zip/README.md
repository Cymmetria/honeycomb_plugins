# Banner

Cymmetria Research, 2018.

https://www.cymmetria.com/

Contact: research@cymmetria.com

The banner honeypot is a customizable banner displayed to a client that connects on the appropriate port.
Its parameters are a port, and optionally a string to display as a banner.

It is released under the MIT license for the use of the community.
