# -*- coding: utf-8 -*-
"""Honeycomb Drupal service."""
from __future__ import unicode_literals
