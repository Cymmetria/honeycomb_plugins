# Drupal 8.50 Honeypot

Cymmetria Research, 2018.

https://www.cymmetria.com/

Contact: research@cymmetria.com

Drupal 8.50 is a low interaction honeypot meant to detect exploitation of CVE-2018-7600.
The html/ directory contains files in order to be fingerprinted correctly by Droopescan (https://github.com/droope/droopescan) and Fingerprinter (https://github.com/erwanlr/Fingerprinter/).
It is released under the MIT license for the use of the community.
