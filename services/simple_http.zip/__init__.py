# -*- coding: utf-8 -*-
"""Honeycomb Simple HTTP Service."""
from __future__ import unicode_literals
