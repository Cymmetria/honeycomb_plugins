# -*- coding: utf-8 -*-
"""Honeycomb MISP Integration."""
from __future__ import unicode_literals
