# -*- coding: utf-8 -*-
"""Honeycomb syslog Integration."""
from __future__ import unicode_literals
