# -*- coding: utf-8 -*-
"""Honeycomb SMS integration for sending alerts via SMS."""
from __future__ import unicode_literals
