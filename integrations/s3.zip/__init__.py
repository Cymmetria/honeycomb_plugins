# -*- coding: utf-8 -*-
"""Honeycomb S3 Integration."""
from __future__ import unicode_literals
